# MIZOKI3 — Single Source of Truth

**Autonomous Strategic Intelligence Infrastructure · v3.5**

This folder is the canonical deliverable package for MIZOKI3. It contains the live website, the executable proof-of-concept, the architectural manifesto, the master pitch deck, and the eleven commissioned brand plates that visualize the system.

---

## Package Contents

### Website (deploy as-is)

| File | Purpose |
|---|---|
| `index.html` | The MIZOKI3 site. Self-contained: HTML + CSS + vanilla JS. Includes the live animated Nexus canvas, the SRPVDAL terminal demo, the bento-grid domain layers, and the 11 image plates as visual deep-dives. Zero build step. |

### Executable Proof

| File | Purpose |
|---|---|
| `mizoki_engine.py` | Pure-Python proof-of-concept. Demonstrates the Decision Control Plane mathematically vetoing a Capital proposal based on a Counsel-ingested covenant stored in the TCKG. Runs with `python3 mizoki_engine.py` — no dependencies. |

### Documents

| File | Purpose |
|---|---|
| `MANIFESTO.md` | Long-form architectural document. Covers Nexus, TCKG, SRPVDAL, DCP, V&A Layer, CSE, DEL, and the five domain layers. Reference Cypher included. |
| `PITCH-DECK.md` | 12-slide master narrative for capital raising and pilot acquisition. Boardroom-ready. |
| `README.md` | This file. |

### Brand Plates (the eleven commissioned visuals)

| File | Section in site |
|---|---|
| `01-hero.png` | Hero — system at a glance |
| `02-editorial.png` | The editorial briefing |
| `03-canonical-loop.png` | SRPVDAL — the canonical loop |
| `04-orchestration-framework.png` | Orchestration framework view |
| `05-ai-orchestration.png` | Full architecture (inputs → loop → outcomes) |
| `06-knowledge-graph.png` | The TCKG substrate |
| `07-legal.png` | Counsel domain |
| `08-estate.png` | Estate domain |
| `09-media-acquisition.png` | Signal domain |
| `10-risk.png` | Risk domain |
| `11-nexus.png` | Nexus orchestration core |

---

## Deploying the Website

The site is a single self-contained HTML file with no build step.

**Local preview:** double-click `index.html` (or `open index.html` on macOS).

**Static hosting** (Vercel / Netlify / Cloudflare Pages / S3 / Cloud Run):
1. Drop the entire folder into the hosting target.
2. Point the root at `index.html`.
3. The 11 PNGs resolve at sibling paths — no path rewriting required.

**Total weight:** ~2.8 MB including all imagery. All images lazy-load below the fold.

---

## Running the Engine

```bash
python3 mizoki_engine.py
```

Expected output: a SRPVDAL orchestration trace showing the Counsel layer ingesting a covenant, the Capital layer proposing a dividend, the Risk layer querying the TCKG, simulating the post-action state, detecting a causal inconsistency, and vetoing the action — with the rejection written back to memory.

This is the moat in 200 lines of code. The same logic ports to a production multi-agent framework (LangGraph, Temporal.io) backed by a bi-temporal graph database (Neo4j, Memgraph, AWS Neptune).

---

## The Thesis (One Paragraph)

MIZOKI3 transforms fragmented enterprise, legal, financial, operational, and customer data into verified autonomous strategic action through Temporal-Causal Knowledge Graphs, SRPVDAL orchestration, continuously learning reasoning agents, and a Decision Control Plane that separates proposal from authorization while refusing to act on correlation alone.

One brain. Many lenses. Shared causal memory.

---

*© 2026 Media Intelligence · MIZOKI3 Platform · Miami, FL · pilot@mizoki3.com*
